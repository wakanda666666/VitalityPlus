
# Vitality+ App Deployment Guide

## How to Host on GitHub Pages
1. Create a GitHub account and sign in.
2. Create a new repository called 'VitalityPlus'.
3. Upload all files from this folder into the repository.
4. Go to Settings > Pages > Select 'main' branch and root folder (/).
5. Save. Wait for the site to build (1-2 mins).
6. Your app will be live at: https://yourusername.github.io/VitalityPlus

## How to Install as PWA
- iPhone: Open the link in Safari > Share > Add to Home Screen.
- Android: Open link in Chrome > Menu > Add to Home Screen.
